function showAlertCSS() {

    alert("CSS button have been clicked!");

} 
function showAlertHTML() {
    alert("HTML button have been clicked!");
} 
function showAlertBOOTSTRAP() {
    alert("BOOTSTRAP button have been clicked!");
} 
function showAlertRUBY() {
    alert("RUBY button have been clicked!");
} 
function showAlertSEEPROJECT() {
    alert("See Project button have been clicked!");
} 
function showAlertGETMYRESUME() {
    alert("Ger My Resume button have been clicked!");
} 